#ifndef TASK15_1_H
#define TASK15_1_H

double func1(double x);
double func2(double x);
double func3(double x);
void write_data(const char *filename, double (*func)(double), int n);

#endif