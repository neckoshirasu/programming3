#ifndef ARRAY_H
#define ARRAY_H

int *create_array(int n);
void print_array(int *arr, int n);

#endif
