#include <stdio.h>

int main(void){
    printf("学籍番号: 36714143\n");
    printf("氏名: 和田小百合\n");
}